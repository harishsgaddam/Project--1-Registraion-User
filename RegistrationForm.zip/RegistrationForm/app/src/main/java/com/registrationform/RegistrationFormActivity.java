package com.registrationform;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.roomdb.Note;
import com.roomdb.NoteDatabase;

import java.lang.ref.WeakReference;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 *
 * Harish Gaddam
 *
 * */

public class RegistrationFormActivity extends AppCompatActivity implements View.OnClickListener {

    private Context mContext = RegistrationFormActivity.this;
    @BindView(R.id.tvHeader) TextView tvHeader;
    @BindView(R.id.ivBack) ImageView ivBack;
    @BindView(R.id.etName) EditText etName;
    @BindView(R.id.etPhone) EditText etPhone;
    @BindView(R.id.etEmail) EditText etEmail;
    @BindView(R.id.etDateOfBirth) EditText etDateOfBirth;
    @BindView(R.id.etAge) EditText etAge;
    @BindView(R.id.btnSubmit) Button btnSubmit;
    @BindView(R.id.btnViewAll) Button btnViewAll;

    String strName="";
    String strPhone="";
    String strEmail="";
    String strDateOfBirth="";
    String strAge="";

    DatePickerDialog datePickerDialog;
    int mYear;
    int mMonth;
    int dayOfMonth;
    Calendar calendar;

    private NoteDatabase noteDatabase;
    private Note note;
    private boolean update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_form);
        ButterKnife.bind(this);

        ivBack.setOnClickListener(view-> { onBackPressed(); });
        etDateOfBirth.setOnClickListener(this);

        noteDatabase = NoteDatabase.getInstance(mContext);
        if ((note = (Note)
                getIntent().getSerializableExtra("note"))!= null)
        {
            tvHeader.setText(R.string.update_user_details);
            update = true;
            btnSubmit.setText("Update");
            etName.setText(note.getName());
            etPhone.setText(note.getPhone());
            etEmail.setText(note.getEmail());
            etDateOfBirth.setText(note.getDateofBirth());
            etAge.setText(note.getAge());
        }

        tvHeader.setText(R.string.registration_form);
        btnSubmit.setOnClickListener(this);
        btnViewAll.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.etDateOfBirth:
                dateOfBirthDialog();
                break;

            case R.id.btnSubmit:
                validation();
                break;

            case R.id.btnViewAll:
                Intent intent = new Intent(RegistrationFormActivity.this, ListDetailsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                break;
        }
    }

    private void validation() {
        strName = etName.getText().toString();
        strPhone = etPhone.getText().toString();
        strEmail = etEmail.getText().toString().trim();
        strDateOfBirth = etDateOfBirth.getText().toString();
        strAge = etAge.getText().toString();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        if (strName.equals("")) {
            etName.setError("Please enter a valid name");
            etName.requestFocus();

        } else if (strPhone.equals("")) {
            etPhone.setError("Please enter a valid phone number");
            etPhone.requestFocus();

        } else if (strEmail.equalsIgnoreCase("")) {
            etEmail.setError("Please enter a email address");
            etEmail.requestFocus();

        } else if (!(strEmail.matches(emailPattern) && strEmail.length() > 0)) {
            etEmail.setError("Please enter a valid email address");
            etEmail.requestFocus();

        } else if (strDateOfBirth.equals("")) {
            etDateOfBirth.setError("Please enter a valid date of birth");
            etDateOfBirth.requestFocus();

        } else if (strAge.equals("")) {
            etAge.setError("Please enter a valid age");
            etAge.requestFocus();

        } else {
            addItemsInRecyclerView();
        }
    }

    public void dateOfBirthDialog() {

        calendar = Calendar.getInstance();
        mYear = calendar.get(Calendar.YEAR);
        mMonth = calendar.get(Calendar.MONTH);
        dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        datePickerDialog = new DatePickerDialog(mContext, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                Date date2 = null;
                Date date = null;

                String dtStart = year + "-" + (month + 1) + "-" + day;
                String dtEnd = mYear + "-" + (mMonth + 1) + "-" + dayOfMonth;
                SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
                try {
                    date = format.parse(dtStart);
                    date2 = format.parse(dtEnd);
                    System.out.println(date);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (date != null && date.before(date2)) {
                    etDateOfBirth.setText("" + day + "/" + (month + 1) + "/" + year);

                } else {
                    Toast.makeText(mContext, "Date of birth should be before today's date.", Toast.LENGTH_SHORT).show();
                }
            }
        }, mYear, mMonth, dayOfMonth);
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    /**-------------------------------------Start--> Room DB -----------------------------------------*/
    private void addItemsInRecyclerView() {
        if (update) {
            note.setName(strName);
            note.setPhone(strPhone);
            note.setEmail(strEmail);
            note.setDateofBirth(strDateOfBirth);
            note.setAge(strAge);

            noteDatabase.getUserDao().updateNote(note);
            setResult(note, 2);
        }
        else {
            note = new Note(strName, strPhone, strEmail,
                    strDateOfBirth, strAge);
            new RegistrationFormActivity.InsertTask(RegistrationFormActivity.this, note).execute();
        }

        Toast.makeText(mContext, "Details added successfully !!", Toast.LENGTH_SHORT).show();
    }

    private void setResult(Note note, int flag) {
        setResult(flag, new Intent().putExtra("note", note));
        finish();
    }

    private static class InsertTask extends AsyncTask<Void,Void,Boolean>
    {
        private WeakReference<RegistrationFormActivity> activityReference;
        private Note note;

        // only retain a weak reference to the activity
        InsertTask(RegistrationFormActivity context, Note note) {
            activityReference = new WeakReference<>(context);
            this.note = note;
        }

        // doInBackground methods runs on a worker thread
        @Override
        protected Boolean doInBackground(Void... objs) {
            // retrieve auto incremented note id
            long j = activityReference.get().noteDatabase.getUserDao().insertNote(note);
            note.setID(j);
            Log.e("ID ", "doInBackground: "+j );
            return true;
        }

        // onPostExecute runs on main thread
        @Override
        protected void onPostExecute(Boolean bool) {
            if (bool){
                activityReference.get().setResult(note,1);
                activityReference.get().finish();
            }
        }
    }
/**------------------------------------End--> Room DB --------------------------------------------*/
}

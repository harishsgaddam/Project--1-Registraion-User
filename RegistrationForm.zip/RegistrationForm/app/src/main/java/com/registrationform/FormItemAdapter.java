package com.registrationform;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.roomdb.Note;

import java.util.List;

/**
 *
 * Harish Gaddam
 *
 * */

public class FormItemAdapter extends RecyclerView.Adapter<FormItemAdapter.ViewHolder>
{
    private Context mContext;
    private List<Note> list;

    public FormItemAdapter(Context context, List<Note> list)
    {
        this.mContext = context;
        this.list = list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_formitem, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position)
    {
        holder.tvName.setText(list.get(position).getName());
        holder.tvPhone.setText(list.get(position).getPhone());
        holder.tvEmail.setText(list.get(position).getEmail());
        holder.tvBirthdayDate.setText(list.get(position).getDateofBirth());
        holder.tvAge.setText(list.get(position).getAge());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void removeItem(int position) {
        list.remove(position);
        // notify the item removed by position
        // to perform recycler view delete animations
        // NOTE: don't call notifyDataSetChanged()
        notifyItemRemoved(position);
    }

    public void restoreItem(Note item, int position) {
        list.add(position, item);
        // notify item added by position
        notifyItemInserted(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        ConstraintLayout viewForeground;
        CardView cardView;
        TextView tvName;
        TextView tvPhone;
        TextView tvEmail;
        TextView tvBirthdayDate;
        TextView tvAge;

        public ViewHolder(View itemView)
        {
            super(itemView);
            viewForeground = itemView.findViewById(R.id.viewForeground);
            cardView = itemView.findViewById(R.id.cardView);
            tvName = itemView.findViewById(R.id.tvName);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvEmail = itemView.findViewById(R.id.tvEmail);
            tvBirthdayDate = itemView.findViewById(R.id.tvBirthdayDate);
            tvAge = itemView.findViewById(R.id.tvAge);
        }

        @Override
        public void onClick(View v) {
            if (mContext instanceof ListDetailsActivity) {
//                ((ListDetailsActivity)mContext).onItemClick(getAdapterPosition());
            }
            Log.e("adapter_position-->", String.valueOf(getAdapterPosition()));
        }
    }
}

package com.registrationform;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.roomdb.Note;
import com.roomdb.NoteDatabase;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 *
 * Harish Gaddam
 *
 * */

public class ListDetailsActivity extends AppCompatActivity implements RecyclerItemTouchHelper.RecyclerItemTouchHelperListener{

    private Context mContext = ListDetailsActivity.this;

    @BindView(R.id.rvcLayout) ConstraintLayout rvcLayout;
    @BindView(R.id.tvHeader) TextView tvHeader;
    @BindView(R.id.tvNoRecords) TextView tvNoRecords;
    @BindView(R.id.ivBack) ImageView ivBack;
    @BindView(R.id.btnAdd) Button btnAdd;
    @BindView(R.id.recyclerView) RecyclerView recyclerView;

    private List<Note> list;
    private NoteDatabase noteDatabase;
    private FormItemAdapter formItemAdapter;
    private int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_details);
        ButterKnife.bind(this);

        ivBack.setVisibility(View.GONE);
        tvHeader.setText(R.string.details);
        btnAdd.setVisibility(View.VISIBLE);
        list = new ArrayList<>();

        btnAdd.setOnClickListener(view-> {
            Intent intent = new Intent(ListDetailsActivity.this, RegistrationFormActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("onResume", "-->Activity_EducationDetails");

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(ListDetailsActivity.this));
        formItemAdapter = new FormItemAdapter(mContext, list);
        recyclerView.setAdapter(formItemAdapter);

        displayList();

        // swipe to delete
        ItemTouchHelper.SimpleCallback itemTouchHelperCallback = new RecyclerItemTouchHelper(0, ItemTouchHelper.LEFT, this);
        new ItemTouchHelper(itemTouchHelperCallback).attachToRecyclerView(recyclerView);

        ItemTouchHelper.SimpleCallback itemTouchHelperCallback1 = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT | ItemTouchHelper.UP)
        {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                // Row is swiped from recycler view
                // remove it from adapter
            }

            @Override
            public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, float dX, float dY, int actionState, boolean isCurrentlyActive) {
                super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
            }
        };

        // attaching the touch helper to recycler view
        new ItemTouchHelper(itemTouchHelperCallback1).attachToRecyclerView(recyclerView);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == 100 && resultCode > 0) {
            if (resultCode == 1) {
                assert data != null;
                list.add((Note) data.getSerializableExtra("note"));
            } else if (resultCode == 2) {
                assert data != null;
                list.set(pos, (Note) data.getSerializableExtra("note"));
            }
            listVisibility();
        }
    }

    private void listVisibility() {
        int emptyMsgVisible = View.GONE;
        if (list.size() == 0) // No item to display
        {
            if (tvNoRecords.getVisibility() == View.GONE)
            {
                emptyMsgVisible = View.VISIBLE;
            }
            tvNoRecords.setVisibility(emptyMsgVisible);
            formItemAdapter.notifyDataSetChanged();
        }
    }

    private void displayList(){
        noteDatabase = NoteDatabase.getInstance(ListDetailsActivity.this);
        new ListDetailsActivity.RetrieveTask(this).execute();
    }

    @Override
    public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction, int position) {
        if (viewHolder instanceof FormItemAdapter.ViewHolder) {
            // get the removed item name to display it in snack bar
            String name = list.get(viewHolder.getAdapterPosition()).getName();

            // backup of removed item for undo purpose
            final Note deletedItem = list.get(viewHolder.getAdapterPosition());
            final int deletedIndex = viewHolder.getAdapterPosition();

            // remove the item from recycler view
            formItemAdapter.removeItem(viewHolder.getAdapterPosition());

            // showing snack bar with Undo option
            Snackbar snackbar = Snackbar
                    .make(rvcLayout, name + " removed from cart!", Snackbar.LENGTH_LONG);
            snackbar.setAction("UNDO", new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    // undo is selected, restore the deleted item
                    formItemAdapter.restoreItem(deletedItem, deletedIndex);
                }
            });
            snackbar.setActionTextColor(Color.YELLOW);
            snackbar.show();
        }
    }

    /*public void onItemClick(int pos) {
        new AlertDialog.Builder(ActivityEducationDetails.this)
                .setTitle("Select Options")
                .setItems(new String[]{"Delete", "Update"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i){
                            case 0:
                                noteDatabase.getEducationDetailsDao().deleteNote(list.get(pos));
                                list.remove(pos);
                                listVisibility();
                                break;
                            case 1:
                                ActivityEducationDetails.this.pos = pos;
                                startActivityForResult(
                                        new Intent(ActivityEducationDetails.this,
                                                ActivityAddPreviousWorkedInfo.class).putExtra("education_details",list.get(pos)),
                                        100);

                                break;
                        }
                    }
                }).show();

    }*/

    private static class RetrieveTask extends AsyncTask<Void,Void,List<Note>> {

        private WeakReference<ListDetailsActivity> activityReference;

        // only retain a weak reference to the activity
        RetrieveTask(ListDetailsActivity context) {
            activityReference = new WeakReference<>(context);
        }

        @Override
        protected List<Note> doInBackground(Void... voids) {
            if (activityReference.get()!=null)
                return activityReference.get().noteDatabase.getUserDao().getUser();
            else
                return null;
        }

        @Override
        protected void onPostExecute(List<Note> notes) {
            if (notes!=null && notes.size()>0 ){
                activityReference.get().list.clear();
                activityReference.get().list.addAll(notes);
                // hides empty text view
                activityReference.get().tvNoRecords.setVisibility(View.GONE);
                activityReference.get().formItemAdapter.notifyDataSetChanged();
            }
        }
    }
}

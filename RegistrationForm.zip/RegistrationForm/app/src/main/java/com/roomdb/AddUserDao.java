package com.roomdb;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

/**
 *  Harish Gaddam
 *
 * */

@Dao
public interface AddUserDao {

/**
 * DAO --> MasterGetProfileInfoData Access Object
 *
 * MasterGetProfileInfoData Access Objects are the main classes where you define your database interactions.
 * They can include a variety of query methods.
 *
 * The class marked with @Dao should either be an interface or an abstract class. At compile time,
 * Room will generate an implementation of this class when it is referenced by a Database.
 *
 * An abstract @Dao class can optionally have a constructor that takes a Database as its only parameter.
 *
 * It is recommended to have multiple Dao classes in your codebase depending on the tables they touch.
 *
 * */

    @Query("SELECT * FROM "+ Constants.TABLE_NAME_NOTE)
    List<Note> getUser();

    /*
    * Insert the object in database
    * @param note, object to be inserted
    */
    @Insert
    long insertNote(Note note);

    /*
    * update the object in database
    * @param note, object to be updated
    */
    @Update
    void updateNote(Note repos);

    /*
    * delete the object from database
    * @param note, object to be deleted
    */
    @Delete
    void deleteNote(Note note);

    // Note... is varargs, here note is an array
    /*
    * delete list of objects from database
    * @param note, array of oject to be deleted
    */
    @Delete
    void deleteNotes(Note... note);

}

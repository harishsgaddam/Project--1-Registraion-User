package com.roomdb;

/**
 *  Harish Gaddam
 *
 * */

public class Constants {
    private Constants() {
    }
    public static final String TABLE_NAME_NOTE ="users";
    public static final String DB_NAME ="registration.db";
}

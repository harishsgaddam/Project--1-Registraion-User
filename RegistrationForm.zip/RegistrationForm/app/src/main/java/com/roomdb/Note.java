package com.roomdb;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import java.io.Serializable;
import java.util.Date;

/**
 *  Harish Gaddam
 *
 * */

@Entity(tableName = Constants.TABLE_NAME_NOTE)
public class Note implements Serializable
{
    @PrimaryKey(autoGenerate = true)
    public long id;

    @ColumnInfo(name = "note_content") // column name will be "note_content" instead of "content" in table

    public String name;
    public String phone;
    public String email;
    public String dateofbirth;
    public String age;
    public Date date;

    public Note(String name, String phone, String email,
                String dateofbirth, String age)
    {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.dateofbirth = dateofbirth;
        this.age = age;
        this.date = new Date(System.currentTimeMillis());
    }

    @Ignore
    public Note(){}

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public long getID() {
        return id;
    }

    public void setID(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDateofBirth() {
        return dateofbirth;
    }

    public void setDateofBirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Note)) return false;

        Note note = (Note) o;

        if (id != note.id) return false;
        return name != null ? name.equals(note.name) : note.name == null;
    }

    @Override
    public int hashCode() {
        int result = (int)id;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Note{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", dateofbirth='" + dateofbirth + '\'' +
                ", age='" + age + '\'' +
                ", date=" + date +
                '}';
    }
}